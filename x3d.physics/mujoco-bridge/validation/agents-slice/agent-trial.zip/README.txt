X3D↔MuJoCo experimental contact-arm/1 package (written by x3d_mcp's bridge tools).
Open x3d/scene.x3d in an X3D browser; import the ZIP into the prototype to compile the supported physical annotations.
records/trial.json was produced by the x3d_mcp simulate tool on native MuJoCo.
