X3D↔MuJoCo experimental contact-arm/1 package.
Open x3d/scene.x3d in an X3D browser for a standard visual snapshot and drag behavior.
Import this ZIP into the prototype to compile the supported physical annotations.
Import resets physics to home; records are observations, not restart checkpoints.
See manifest.json for supported mappings, coordinate conventions and losses.
