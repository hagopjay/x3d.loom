const { chromium } = require('playwright');
const fs = require('fs');
const cfg = JSON.parse(fs.readFileSync(__dirname + '/wit_cfg.json'));
const only = process.argv[2];
(async () => {
  const browser = await chromium.launch();
  const out = {};
  for (const f of Object.keys(cfg)) {
    if (only && !f.startsWith(only)) continue;
    const c = cfg[f];
    if ([10,14,15,16].includes(c._n) && /^(fault|twin)/.test(f)) { out[f] = { skipped: 'reasoned: scene needs X_ITE component chunks (EventUtilities/Text/Scripting/KeyDeviceSensor) that the kit does not ship' }; continue; }
    if (!c.probe) { out[f] = { skipped: 'no probe (reasoned)' }; continue; }
    const page = await browser.newPage({ viewport: { width: 640, height: 480 } });
    const logs = [];
    page.on('console', m => logs.push(m.type() + ': ' + m.text()));
    page.on('pageerror', e => logs.push('pageerror: ' + e.message));
    await page.goto('http://127.0.0.1:8765/author-a/_page.html?f=' + f);
    let loaded = true;
    try {
      await page.waitForFunction(() => { const b = document.querySelector('x3d-canvas')?.browser; return b && b.currentScene && b.currentScene.worldURL && b.currentScene.worldURL.includes('.x3d'); }, null, { timeout: 15000 });
    } catch (e) { loaded = false; }
    await page.waitForTimeout(500);
    const samples = [];
    const steps = c.steps || ['s', 1000, 's', 1000, 's', 1000, 's'];
    const t0 = Date.now();
    const sample = async () => {
      const r = await page.evaluate((probe) => {
        const sc = document.querySelector('x3d-canvas').browser.currentScene;
        return probe.map(([n, fld]) => { try { const v = sc.getNamedNode(n)[fld]; return String(v); } catch (e) { return 'ERR ' + e.message; } });
      }, c.probe);
      samples.push({ t: +((Date.now() - t0) / 1000).toFixed(2), v: r });
    };
    for (const s of steps) {
      if (s === 's') await sample();
      else if (typeof s === 'number') await page.waitForTimeout(s);
      else if (s[0] === 'click') { await page.mouse.move(s[1], s[2]); await page.mouse.down(); await page.mouse.up(); }
      else if (s[0] === 'move') await page.mouse.move(s[1], s[2], { steps: 5 });
      else if (s[0] === 'down') await page.mouse.down();
      else if (s[0] === 'up') await page.mouse.up();
      else if (s[0] === 'type') await page.keyboard.type(s[1], { delay: 80 });
      else if (s[0] === 'press') await page.keyboard.press(s[1]);
    }
    out[f] = { loaded, probe: c.probe, samples, console: logs };
    await page.close();
  }
  fs.writeFileSync(__dirname + (only ? '/witness_' + only + '.json' : '/witness.json'), JSON.stringify(out, null, 1));
  await browser.close();
})();
