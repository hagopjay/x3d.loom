const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.goto('http://127.0.0.1:8765/author-a/_page.html?f=decoy-01.x3d');await p.waitForTimeout(3000);
console.log(b.version());
console.log(await p.evaluate(()=>{const br=document.querySelector('x3d-canvas').browser;
 const g=document.createElement('canvas').getContext('webgl2'); const e=g&&g.getExtension('WEBGL_debug_renderer_info');
 return JSON.stringify({comps:[...br.supportedComponents].map(c=>c.name+':'+c.level).join(','),ver:br.version,gl:e?g.getParameter(e.UNMASKED_RENDERER_WEBGL):String(g)})}));
await b.close()})()
