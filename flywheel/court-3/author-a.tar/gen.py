import json, os
D = os.path.dirname(os.path.abspath(__file__))
COMP = {'TouchSensor':('PointingDeviceSensor',1),'PlaneSensor':('PointingDeviceSensor',1),'ProximitySensor':('EnvironmentalSensor',1),
 'Collision':('Navigation',2),'Anchor':('Networking',1),'LoadSensor':('Networking',3),'Inline':('Networking',2),'LOD':('Navigation',1),
 'PointLight':('Lighting',2),'PositionDamper':('Followers',1)}
def doc(desc, body, profile='Auto', title=None):
    comps=''
    if profile=='Auto':
        profile='Interchange'
        seen={}
        for k,(c,l) in COMP.items():
            if '<'+k+' ' in body or '<'+k+'>' in body or '<'+k+'/' in body: seen[c]=max(seen.get(c,0),l)
        comps=''.join(f"    <component name='{c}' level='{l}'/>\n" for c,l in sorted(seen.items()))
    cam = '' if '<Viewpoint' in body else "    <Viewpoint DEF='Cam' description='Front' position='0 0 10'/>\n"
    return f"""<?xml version='1.0' encoding='UTF-8'?>
<X3D profile='{profile}' version='4.0'>
  <head>
{comps}    <meta name='description' content='{desc}'/>
    <meta name='title' content='{title or "behaviour test scene"}'/>
  </head>
  <Scene>
{cam}{body}
  </Scene>
</X3D>
"""
def shape(col='0.8 0.2 0.2', geom='<Box/>'):
    return f"<Shape><Appearance><Material diffuseColor='{col}'/></Appearance>{geom}</Shape>"
E = []  # entries
def add(n, cat, desc, fn, fault, spec, viewer, profile='Auto', wit=None):
    E.append(dict(n=n, cat=cat, desc=desc, fn=fn, fault=fault, spec=spec, viewer=viewer, profile=profile, wit=wit or {}))

# 1 wiring: field name typo
add(1,'route-wiring','A red box named Spinner rotates continuously about the vertical axis, one turn every 4 seconds.',
 lambda v: f"""    <Transform DEF='Spinner'>{shape()}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <OrientationInterpolator DEF='Spin' key='0 0.5 1' keyValue='0 1 0 0  0 1 0 3.14159  0 1 0 6.28318'/>
    <ROUTE fromNode='Clock' fromField='{v}' toNode='Spin' toField='set_fraction'/>
    <ROUTE fromNode='Spin' fromField='value_changed' toNode='Spinner' toField='set_rotation'/>""",
 ('fraction_change','fraction_changed'),
 'fault: ROUTE fromField names a field that does not exist on TimeSensor (fraction_change); spec 4.0 section on ROUTE requires fromField to name an output field of the node','The box never rotates.',
 wit=dict(probe=[['Spinner','rotation']]))
# 2 route-type
add(2,'route-type','A lamp box named Lamp slides from the left to the right of the view and back, driven by a clock.',
 lambda v: f"""    <Transform DEF='Lamp' translation='-3 0 0'>{shape('1 1 0')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <PositionInterpolator DEF='Slide' key='0 0.5 1' keyValue='-3 0 0  3 0 0  -3 0 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Slide' toField='set_fraction'/>
    <ROUTE fromNode='Slide' fromField='value_changed' toNode='Lamp' toField='{v}'/>""",
 ('set_rotation','set_translation'),
 'fault: SFVec3f value_changed routed to an SFRotation field; spec ROUTE rule: source and destination field types must be identical','The lamp does not slide.',
 wit=dict(probe=[['Lamp','translation'],['Lamp','rotation']]))
# 3 route-access
add(3,'route-access','A leader box moves along x under animation; a second box named Follower copies the leader position by a ROUTE from the leader translation output.',
 lambda v: f"""    <Transform DEF='Leader' translation='-3 1 0'>{shape('0 0.6 1')}</Transform>
    <Transform DEF='Follower' translation='-3 -1 0'>{shape('0 1 0.4')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <PositionInterpolator DEF='Path' key='0 1' keyValue='-3 1 0  3 1 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Path' toField='set_fraction'/>
    <ROUTE fromNode='Path' fromField='value_changed' toNode='Leader' toField='set_translation'/>
    <ROUTE fromNode='Leader' fromField='{v}' toNode='Follower' toField='set_translation'/>""",
 ('set_translation','translation_changed'),
 'fault: ROUTE source is the inputOnly set_translation event of Leader; spec requires a route source to be an outputOnly or inputOutput (_changed) field','Follower stays at its start position.',
 wit=dict(probe=[['Leader','translation'],['Follower','translation']]))
# 4 timing-loop
add(4,'timing-loop','A pulsing indicator named Pulse grows and shrinks forever, one pulse every 1.5 seconds.',
 lambda v: f"""    <Transform DEF='Pulse'>{shape('1 0.5 0','<Sphere/>')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='1.5' loop='{v}' startTime='1'/>
    <PositionInterpolator DEF='Grow' key='0 0.5 1' keyValue='1 1 1  2 2 2  1 1 1'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Grow' toField='set_fraction'/>
    <ROUTE fromNode='Grow' fromField='value_changed' toNode='Pulse' toField='set_scale'/>""",
 ('false','true'),
 None,'The indicator never pulses.',
 wit=dict(probe=[['Pulse','scale'],['Clock','isActive']], steps=['s',2000,'s',2000,'s',2000,'s']))
# 5 wiring: DEF case mismatch
add(5,'route-wiring','A door panel named Door swings open about its hinge and then closes, repeating every 6 seconds.',
 lambda v: f"""    <Transform DEF='Door' center='-1 0 0' translation='1 0 0'>{shape('0.5 0.3 0.1','<Box size="2 3 0.2"/>')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='6' loop='true'/>
    <OrientationInterpolator DEF='Swing' key='0 0.5 1' keyValue='0 1 0 0  0 1 0 1.5  0 1 0 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Swing' toField='set_fraction'/>
    <ROUTE fromNode='Swing' fromField='value_changed' toNode='{v}' toField='set_rotation'/>""",
 ('door','Door'),
 'fault: ROUTE toNode references an undefined DEF name (case differs from DEF Door); spec requires ROUTE nodes to name DEF-ed nodes in scope','The door never moves.',
 wit=dict(probe=[['Door','rotation']]))
# 6 interp count mismatch
add(6,'interpolator-keys','An elevator box named Cabin rises through three floors at heights 0, 3 and 6 with equal timing over 6 seconds, then jumps back and repeats.',
 lambda v: f"""    <Transform DEF='Cabin'>{shape('0.6 0.6 0.9')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='6' loop='true'/>
    <PositionInterpolator DEF='Lift' key='0 0.5 1' keyValue='{v}'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Lift' toField='set_fraction'/>
    <ROUTE fromNode='Lift' fromField='value_changed' toNode='Cabin' toField='set_translation'/>""",
 ('0 0 0  0 3 0','0 0 0  0 3 0  0 6 0'),
 'fault: PositionInterpolator has 3 keys but only 2 keyValue triples; spec says keyValue shall contain exactly as many values as keys','The cabin does not follow the intended three-floor path (stuck or wrong).',
 wit=dict(probe=[['Cabin','translation']], steps=['s',1000,'s',1000,'s',1000,'s',1000,'s']))
# 7 keys non monotonic
add(7,'interpolator-keys','A panel named Fader fades from invisible to opaque over the first half of an 8 second cycle, then holds fully opaque.',
 lambda v: f"""    <Shape DEF='Fader'><Appearance><Material DEF='Mat' diffuseColor='1 1 1' transparency='1'/></Appearance><Box/></Shape>
    <TimeSensor DEF='Clock' cycleInterval='8' loop='true'/>
    <ScalarInterpolator DEF='Fade' key='{v}' keyValue='1 0 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Fade' toField='set_fraction'/>
    <ROUTE fromNode='Fade' fromField='value_changed' toNode='Mat' toField='set_transparency'/>""",
 ('0 0.8 0.5','0 0.5 1'),
 'fault: interpolator key values are not monotonically non-decreasing (0.8 then 0.5); spec requires keys in non-decreasing order','The fade is wrong: transparency does not ramp over the first half then hold.',
 wit=dict(probe=[['Mat','transparency']], steps=['s',1000,'s',1000,'s',1000,'s',1000,'s',1000,'s',1000,'s']))
# 8 pointing: sensor not sibling
add(8,'pointing-sensor','Clicking the green sphere named Button starts a spin timer: the TouchSensor touchTime starts the clock Spin and the clock becomes active.',
 lambda v: ("""    <Group>
      <TouchSensor DEF='Touch'/>
      <Transform DEF='Button'>%s</Transform>
    </Group>""" % shape('0 0.8 0','<Sphere/>') if v else """    <Group>
      <TouchSensor DEF='Touch'/>
    </Group>
    <Group>
      <Transform DEF='Button'>%s</Transform>
    </Group>""" % shape('0 0.8 0','<Sphere/>')) + """
    <TimeSensor DEF='Spin' cycleInterval='3' loop='false'/>
    <ROUTE fromNode='Touch' fromField='touchTime' toNode='Spin' toField='set_startTime'/>""",
 (False,True),
 None,'Clicking the sphere does nothing.',
 wit=dict(probe=[['Spin','isActive'],['Touch','isOver']], steps=['s',500,['move',320,240],500,'s',['click',320,240],1000,'s',500,'s']))
# 9 drag: min>max
add(9,'drag-sensor','A slider handle named Handle can be dragged by the pointer horizontally but must stay within x from 0 to 2 and fixed at y equal to 0.',
 lambda v: f"""    <Group>
      <PlaneSensor DEF='Drag' {v}/>
      <Transform DEF='Handle'>{shape('0.9 0.9 0.2','<Sphere radius="0.5"/>')}</Transform>
    </Group>
    <ROUTE fromNode='Drag' fromField='translation_changed' toNode='Handle' toField='set_translation'/>""",
 ("minPosition='2 0' maxPosition='0 0'","minPosition='0 0' maxPosition='2 0'"),
 None,'Dragging moves the handle freely beyond the intended range (and vertically).',
 wit=dict(probe=[['Drag','translation_changed']], steps=['s',500,['move',320,240],['down'],['move',500,150],['move',620,60],['up'],300,'s']))
# 10 trigger: enabled default
add(10,'trigger-toggle','A cube named Spinner stays still until the user clicks the red ball; each click toggles the spin clock on or off.',
 lambda v: f"""    <Transform DEF='Spinner'>{shape()}</Transform>
    <Transform translation='3 0 0'><TouchSensor DEF='Switch'/>{shape('1 0 0','<Sphere radius="0.4"/>')}</Transform>
    <BooleanToggle DEF='Flip'/>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true' {v}/>
    <OrientationInterpolator DEF='Turn' key='0 0.5 1' keyValue='0 1 0 0  0 1 0 3.14159  0 1 0 6.28318'/>
    <ROUTE fromNode='Switch' fromField='isActive' toNode='Flip' toField='set_boolean'/>
    <ROUTE fromNode='Flip' fromField='toggle_changed' toNode='Clock' toField='set_enabled'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Turn' toField='set_fraction'/>
    <ROUTE fromNode='Turn' fromField='value_changed' toNode='Spinner' toField='set_rotation'/>""",
 ('',"enabled='false'"),
 None,'The cube spins from the moment the scene loads, before any click.',
 profile='Immersive',
 wit=dict(probe=[['Spinner','rotation'],['Clock','enabled']], steps=['s',1000,'s',1000,'s']))
# 11 follower tau
add(11,'follower','A target ball named Target moves right over 2 seconds; a second ball named Chaser follows it with a smooth lag using a damper (time constant 0.5 s), so it trails behind the target.',
 lambda v: f"""    <Transform DEF='Target'>{shape('1 0 0','<Sphere radius="0.4"/>')}</Transform>
    <Transform DEF='Chaser' translation='0 -1 0'>{shape('0 0 1','<Sphere radius="0.4"/>')}</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <PositionInterpolator DEF='Path' key='0 0.5 1' keyValue='-3 0 0  3 0 0  3 0 0'/>
    <PositionDamper DEF='Lag' tau='{v}' tolerance='0.001' initialDestination='-3 -1 0' initialValue='-3 -1 0' order='3'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Path' toField='set_fraction'/>
    <ROUTE fromNode='Path' fromField='value_changed' toNode='Target' toField='set_translation'/>
    <ROUTE fromNode='Path' fromField='value_changed' toNode='Lag' toField='set_destination'/>
    <ROUTE fromNode='Lag' fromField='value_changed' toNode='Chaser' toField='set_translation'/>""",
 ('0','0.5'),
 None,'The second ball moves in lockstep with the target instead of trailing.',
 wit=dict(probe=[['Target','translation'],['Chaser','translation']], steps=['s',500,'s',500,'s',500,'s',500,'s']))
# 12 proximity size 0
add(12,'environment-sensor','A lamp named Porch turns on while the viewer is inside a 30 by 30 by 30 zone centred on the origin; the viewer starts at 0 0 10, inside the zone.',
 lambda v: f"""    <ProximitySensor DEF='Zone' size='{v}'/>
    <PointLight DEF='Porch' on='false' location='0 2 2'/>
    <Transform>{shape('0.7 0.7 0.7')}</Transform>
    <ROUTE fromNode='Zone' fromField='isActive' toNode='Porch' toField='set_on'/>""",
 ('0 0 0','30 30 30'),
 None,'The lamp never turns on.',
 wit=dict(probe=[['Zone','isActive'],['Porch','on']], steps=['s',1000,'s']))
# 13 collision outside
add(13,'environment-sensor','Walking into the wall named Wall fires the collision event: the Collision node holds the Wall geometry and its collideTime starts a flash timer.',
 lambda v: ("""    <Collision DEF='Hit'>
      <Transform DEF='Wall' translation='0 0 -2'>%s</Transform>
    </Collision>""" % shape('0.5 0.5 0.5','<Box size="6 3 0.3"/>') if v else """    <Collision DEF='Hit'/>
    <Transform DEF='Wall' translation='0 0 -2'>%s</Transform>""" % shape('0.5 0.5 0.5','<Box size="6 3 0.3"/>')) + """
    <TimeSensor DEF='Flash' cycleInterval='0.5'/>
    <ROUTE fromNode='Hit' fromField='collideTime' toNode='Flash' toField='set_startTime'/>""",
 (False,True),
 None,'The wall is not collidable; the avatar walks through it and no collision event fires.',
 wit=None)
# 14 key sensor / string sensor
add(14,'key-sensor','A label named Echo shows the typed word only after Enter is pressed: a StringSensor finalText feeds the label, so partial typing is not displayed.',
 lambda v: f"""    <StringSensor DEF='Typed' deletionAllowed='true'/>
    <Shape><Appearance><Material diffuseColor='1 1 1'/></Appearance>
      <Text DEF='Echo' string='""'><FontStyle justify='"MIDDLE"'/></Text>
    </Shape>
    <ROUTE fromNode='Typed' fromField='{v}' toNode='Echo' toField='set_string'/>""",
 ('enteredText','finalText'),
 None,'The label updates on every keystroke, showing partial text.',
 profile='Immersive',
 wit=dict(probe=[['Echo','string']], steps=['s',['click',320,240],['type','hi'],300,'s',['press','Enter'],300,'s']))
# 15 switch index out of range
add(15,'switch-sequencer','Three lamps in a Switch named Lamps light one at a time in a repeating cycle of 0, 1, 2, 0: an IntegerSequencer feeds whichChoice every second.',
 lambda v: f"""    <Switch DEF='Lamps' whichChoice='0'>
      <Transform translation='-3 0 0'>{shape('1 0 0','<Sphere/>')}</Transform>
      <Transform translation='0 0 0'>{shape('0 1 0','<Sphere/>')}</Transform>
      <Transform translation='3 0 0'>{shape('0 0 1','<Sphere/>')}</Transform>
    </Switch>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <IntegerSequencer DEF='Seq' key='0 0.25 0.5 0.75' keyValue='{v}'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Seq' toField='set_fraction'/>
    <ROUTE fromNode='Seq' fromField='value_changed' toNode='Lamps' toField='set_whichChoice'/>""",
 ('0 1 2 3','0 1 2 0'),
 None,'During the last quarter of each cycle no lamp is shown.',
 profile='Immersive',
 wit=dict(probe=[['Lamps','whichChoice']], steps=['s',500,'s',1000,'s',1000,'s',1000,'s',1000,'s']))
# 16 script handler name
add(16,'script','A Script named Counter counts ticks of a one second clock and writes a label such as ticks: 3 into the Text node Readout.',
 lambda v: f"""    <TimeSensor DEF='Clock' cycleInterval='1' loop='true'/>
    <Script DEF='Counter'>
      <field name='tick' type='SFTime' accessType='inputOnly'/>
      <field name='label' type='SFString' accessType='outputOnly'/>
<![CDATA[ecmascript:
var n = 0;
function {v}(value) {{ n++; label = 'ticks: ' + n; }}
]]>
    </Script>
    <Shape><Appearance><Material diffuseColor='1 1 1'/></Appearance><Text DEF='Readout' string='"ticks: 0"'/></Shape>
    <ROUTE fromNode='Clock' fromField='cycleTime' toNode='Counter' toField='tick'/>
    <ROUTE fromNode='Counter' fromField='label' toNode='Readout' toField='set_string'/>""",
 ('onTick','tick'),
 None,'The readout stays at ticks: 0 forever.',
 profile='Immersive',
 wit=dict(probe=[['Readout','string']], steps=['s',1200,'s',1000,'s',1000,'s']))
# 17 viewpoint order
add(17,'viewpoint-binding','The scene opens at the wide viewpoint named Overview; the Closeup viewpoint is only reached by navigation.',
 lambda v: ("""    <Viewpoint DEF='Overview' description='Overview' position='0 0 20'/>
    <Viewpoint DEF='Closeup' description='Closeup' position='0 0 4'/>""" if v else """    <Viewpoint DEF='Closeup' description='Closeup' position='0 0 4'/>
    <Viewpoint DEF='Overview' description='Overview' position='0 0 20'/>""") + f"""
    {shape('0.3 0.7 0.3')}""",
 (False,True),
 None,'The scene opens zoomed in at Closeup rather than at the wide Overview.',
 wit=dict(probe=[['Overview','isBound'],['Closeup','isBound']], steps=['s',500,'s']))
# 18 loadsensor containerField
INNER = "twin-01.x3d"
add(18,'load-sensor','A LoadSensor named Loader watches the Inline named Model and, once loaded, turns the lamp Ready on via isLoaded.',
 lambda v: f"""    <LoadSensor DEF='Loader' timeOut='10'>
      <Inline DEF='Model' load='{v}' url='"{INNER}"'/>
    </LoadSensor>
    <PointLight DEF='Ready' on='false'/>
    <ROUTE fromNode='Loader' fromField='isLoaded' toNode='Ready' toField='set_on'/>""",
 ('false','true'),
 None,'The ready lamp never switches on because the watched Inline is never loaded.',
 wit=dict(probe=[['Loader','isLoaded'],['Ready','on']], steps=['s',1000,'s',1000,'s']))
# 19 anchor
add(19,'anchor-navigation','Clicking the blue box (an Anchor) jumps the view to the Viewpoint DEF named CloseUp.',
 lambda v: f"""    <Viewpoint DEF='Cam2' description='Wide' position='0 0 12'/>
    <Viewpoint DEF='CloseUp' description='Close up' position='0 0 3'/>
    <Anchor url='"#{v}"' description='Go close'>{shape('0 0 1')}</Anchor>""",
 ('Closeup','CloseUp'),
 None,'Clicking the box does not move the view to the close viewpoint.',
 wit=dict(probe=[['CloseUp','isBound'],['Cam2','isBound']], steps=['s',500,['move',320,240],400,['click',320,240],1000,'s']))
# 20 LOD ranges
add(20,'lod','A LOD node named Detail shows a detailed cylinder when the viewer is closer than 5 units, a sphere between 5 and 20 units and a simple box beyond 20 units; the viewer sits 10 units away so the sphere is the expected level.',
 lambda v: f"""    <LOD DEF='Detail' range='{v}'>
      {shape('1 0 0','<Cylinder/>')}
      {shape('0 1 0','<Sphere/>')}
      {shape('0 0 1','<Box/>')}
    </LOD>""",
 ('20 5','5 20'),
 'fault: LOD range values are not in increasing order (20 then 5); spec requires range values to be monotonically increasing','A different level than the intended medium one is shown.',
 wit=dict(probe=[['Detail','level_changed']], steps=['s',800,'s']))

wit = {}
for e in E:
    n = e['n']; ff, tf = e['fault']
    for kind, v in (('fault', ff), ('twin', tf)):
        name = f"{kind}-{n:02d}.x3d"
        open(os.path.join(D,name),'w').write(doc(e['desc'], e['fn'](v), e['profile']))
        wit[name] = dict(e['wit']); wit[name]['_n']=n
json.dump(wit, open(os.path.join(D,'wit_cfg.json'),'w'), indent=1)
json.dump({e['n']:dict(cat=e['cat'],spec=e['spec'],viewer=e['viewer']) for e in E}, open(os.path.join(D,'_meta.json'),'w'), indent=1)

# ---- decoys
DEC = {}
def dec(n, cat, desc, body, why, intent, probe, steps=None, profile='Auto'):
    name=f"decoy-{n:02d}.x3d"
    open(os.path.join(D,name),'w').write(doc(desc, body, profile))
    wit[name]=dict(probe=probe, steps=steps or ['s',1000,'s',1000,'s'], _n=n)
    DEC[name]=dict(category=cat,intent=intent,why_suspicious=why)
dec(1,'route-wiring','A leader box moves along x; a second box named Mirror copies it by routing the plain inputOutput field name translation (no set_ or _changed suffix) from Leader to Mirror.',
"""    <Transform DEF='Leader' translation='-3 1 0'>%s</Transform>
    <Transform DEF='Mirror' translation='-3 -1 0'>%s</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <PositionInterpolator DEF='Path' key='0 1' keyValue='-3 1 0  3 1 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Path' toField='set_fraction'/>
    <ROUTE fromNode='Path' fromField='value_changed' toNode='Leader' toField='translation'/>
    <ROUTE fromNode='Leader' fromField='translation' toNode='Mirror' toField='translation'/>""" % (shape('0 0.6 1'),shape('0 1 0.4')),
 'The Leader to Mirror ROUTE uses the plain name translation with no set_ or _changed affix, which a hasty reviewer may flag as a nonexistent field; the standard allows the plain name of an inputOutput field.',
 'Mirror follows Leader along x.', [['Leader','translation'],['Mirror','translation']])
dec(2,'timing-loop','A pulse sphere named Pulse grows and shrinks forever; the clock has a stopTime earlier than its startTime, which is ignored by the standard, so it keeps looping.',
"""    <Transform DEF='Pulse'>%s</Transform>
    <TimeSensor DEF='Clock' cycleInterval='1.5' loop='true' startTime='5' stopTime='2'/>
    <PositionInterpolator DEF='Grow' key='0 0.5 1' keyValue='1 1 1  2 2 2  1 1 1'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Grow' toField='set_fraction'/>
    <ROUTE fromNode='Grow' fromField='value_changed' toNode='Pulse' toField='set_scale'/>""" % shape('1 0.5 0','<Sphere/>'),
 'stopTime is set but smaller than startTime and loop is true, which looks like a clock that stops at once; per the standard a stopTime less than or equal to startTime is ignored.',
 'Pulse scales continuously.', [['Pulse','scale'],['Clock','isActive']])
dec(3,'interpolator-keys','A hopping ball named Hopper jumps instantly from x equal to -3 to x equal to 3 at half time: repeated key 0.5 with two different values deliberately makes a step.',
"""    <Transform DEF='Hopper' translation='-3 0 0'>%s</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true'/>
    <PositionInterpolator DEF='Hop' key='0 0.5 0.5 1' keyValue='-3 0 0  -3 0 0  3 0 0  3 0 0'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='Hop' toField='set_fraction'/>
    <ROUTE fromNode='Hop' fromField='value_changed' toNode='Hopper' toField='set_translation'/>""" % shape('0.9 0.4 0.1','<Sphere/>'),
 'Duplicate key value 0.5 looks like a keys error; the standard requires non-decreasing keys, so equal neighbours are legal and give a discontinuity.',
 'Hopper stays at -3 for half the cycle then at 3.', [['Hopper','translation']], ['s',500,'s',1000,'s',1000,'s',1000,'s',1000,'s'])
dec(4,'route-wiring','Two touch sensors both start the same spin clock (several ROUTEs into one field), and one clock fraction drives two interpolators (several ROUTEs from one field).',
"""    <Group><TouchSensor DEF='TouchA'/><Transform translation='-3 0 0'>%s</Transform></Group>
    <Group><TouchSensor DEF='TouchB'/><Transform translation='3 0 0'>%s</Transform></Group>
    <Transform DEF='SpinnerA' translation='0 2 0'>%s</Transform>
    <Transform DEF='SpinnerB' translation='0 -2 0'>%s</Transform>
    <TimeSensor DEF='Clock' cycleInterval='4' loop='true' enabled='true'/>
    <OrientationInterpolator DEF='TurnA' key='0 0.5 1' keyValue='0 1 0 0  0 1 0 3.14159  0 1 0 6.28318'/>
    <OrientationInterpolator DEF='TurnB' key='0 0.5 1' keyValue='1 0 0 0  1 0 0 3.14159  1 0 0 6.28318'/>
    <ROUTE fromNode='TouchA' fromField='touchTime' toNode='Clock' toField='set_startTime'/>
    <ROUTE fromNode='TouchB' fromField='touchTime' toNode='Clock' toField='set_startTime'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='TurnA' toField='set_fraction'/>
    <ROUTE fromNode='Clock' fromField='fraction_changed' toNode='TurnB' toField='set_fraction'/>
    <ROUTE fromNode='TurnA' fromField='value_changed' toNode='SpinnerA' toField='set_rotation'/>
    <ROUTE fromNode='TurnB' fromField='value_changed' toNode='SpinnerB' toField='set_rotation'/>""" % (shape('1 0 0','<Sphere/>'),shape('0 0 1','<Sphere/>'),shape('0.8 0.8 0'),shape('0.8 0 0.8')),
 'Fan-in (two ROUTEs to Clock.set_startTime) and fan-out (one output to two interpolators) look like duplicate or conflicting routes; both are legal.',
 'Both spinners rotate from the shared clock.', [['SpinnerA','rotation'],['SpinnerB','rotation']])
dec(5,'drag-sensor','A handle named Handle can be dragged anywhere with no limits: minPosition is deliberately greater than maxPosition, which the standard defines as no constraint.',
"""    <Group>
      <PlaneSensor DEF='Drag' minPosition='1 1' maxPosition='-1 -1' autoOffset='true'/>
      <Transform DEF='Handle'>%s</Transform>
    </Group>
    <ROUTE fromNode='Drag' fromField='translation_changed' toNode='Handle' toField='set_translation'/>""" % shape('0.9 0.9 0.2','<Sphere radius="0.5"/>'),
 'min greater than max looks like swapped limits; per the standard this means unconstrained on that axis, which is exactly the intent.',
 'Handle can be dragged anywhere.', [['Drag','translation_changed']],
 ['s',500,['move',320,240],['down'],['move',500,150],['move',620,60],['up'],300,'s'])
json.dump(wit, open(os.path.join(D,'wit_cfg.json'),'w'), indent=1)
json.dump(DEC, open(os.path.join(D,'_dec.json'),'w'), indent=1)
