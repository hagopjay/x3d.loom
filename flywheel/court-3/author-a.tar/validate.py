import glob, json, os
from lxml import etree
D=os.path.dirname(os.path.abspath(__file__))
xs=etree.XMLSchema(etree.parse(D+'/../kit/xsd/x3d-4.0.xsd'))
r={}
for p in sorted(glob.glob(D+'/*-[0-9][0-9].x3d')):
    n=os.path.basename(p)
    try: d=etree.parse(p)
    except Exception as e: r[n]=('NOT_WELLFORMED',str(e)); continue
    ok=xs.validate(d)
    r[n]=(ok, '' if ok else str(xs.error_log.last_error)[:200])
json.dump(r,open(D+'/xsd.json','w'),indent=1)
for k,v in r.items():
    if v[0] is not True: print(k,v)
print(len(r))
