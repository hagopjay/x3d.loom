import json, os
D = os.path.dirname(os.path.abspath(__file__))
HEAD = """<?xml version="1.0" encoding="UTF-8"?>
<X3D profile='{profile}' version='4.0' xmlns:xsd='http://www.w3.org/2001/XMLSchema-instance' xsd:noNamespaceSchemaLocation='https://www.web3d.org/specifications/x3d-4.0.xsd'>
  <head>
{comps}    <meta name='title' content='{name}'/>
    <meta name='description' content='{desc}'/>
  </head>
  <Scene>
{body}
  </Scene>
</X3D>
"""
def write(fn, desc, body, profile='Interchange', comps=''):
    c = ''.join("    <component name='%s' level='%d'/>\n" % x for x in comps) if comps else ''
    open(os.path.join(D, fn), 'w').write(HEAD.format(profile=profile, comps=c, name=fn, desc=desc, body=body))

VP = "    <Viewpoint position='0 0 8' description='Front'/>\n"
CUBE_PTS = "-1 -1 -1, 1 -1 -1, 1 1 -1, -1 1 -1, -1 -1 1, 1 -1 1, 1 1 1, -1 1 1"
CUBE_IDX = "4 5 6 7 -1 1 0 3 2 -1 5 1 2 6 -1 0 4 7 3 -1 7 6 2 3 -1 0 1 5 4 -1"
def cube(idx=CUBE_IDX, ifs_extra='', inner='', mat="<Material diffuseColor='0.2 0.5 0.9'/>", pts=CUBE_PTS, DEF='Crate'):
    return f"""    <Transform rotation='1 1 0 0.6'>
      <Shape DEF='{DEF}'>
        <Appearance>{mat}</Appearance>
        <IndexedFaceSet coordIndex='{idx}' {ifs_extra}>
          <Coordinate point='{pts}'/>{inner}
        </IndexedFaceSet>
      </Shape>
    </Transform>
"""
def sph(extra='', mat="<Material diffuseColor='0.8 0.2 0.2'/>"):
    return f"<Shape><Appearance>{mat}</Appearance><Sphere {extra}/></Shape>"

F = {}  # n -> dict(desc, fault, twin, profile, comps, cat, fault_s, seen, spec, note)
def add(n, cat, desc, fb, tb, fault, seen, spec, profile='Interchange', comps=''):
    F[n] = dict(cat=cat, desc=desc, fb=VP + fb, tb=VP + tb, fault=fault, seen=seen, spec=spec, profile=profile, comps=comps)

# 01
add(1, 'geometry-indices', 'A blue crate built from eight points and six quad faces, seen at an angle.',
    cube(CUBE_IDX.replace('4 5 6 7', '4 5 6 8', 1)), cube(),
    'One face of the indexed face set references vertex index 8 but only vertices 0 to 7 exist.',
    'A face missing or broken, possibly a spike or load warning.', 'error: coordIndex entry must be less than the number of Coordinate points (IndexedFaceSet rule)')
# 02
lod = lambda r: f"""    <Transform translation='0 0 0'>
      <LOD range='{r}'>
        <Shape DEF='NearDetail'><Appearance><Material diffuseColor='0.9 0.1 0.1'/></Appearance><Sphere radius='1.5'/></Shape>
        <Shape DEF='MidDetail'><Appearance><Material diffuseColor='0.1 0.8 0.1'/></Appearance><Box size='2 2 2'/></Shape>
        <Shape DEF='FarDetail'><Appearance><Material diffuseColor='0.1 0.1 0.9'/></Appearance><Cone/></Shape>
      </LOD>
    </Transform>
"""
add(2, 'lod-switch', 'A three-level LOD: sphere when close (under 5 m), box between 5 m and 15 m, cone beyond 15 m. The viewer stands 8 m away, so the box is expected.',
    lod('0 5 15'), lod('5 15'),
    'LOD range has three entries for three children; it must have one fewer entry than children.',
    'The distant cone is drawn instead of the box.', 'error: LOD range field must contain n-1 values for n children')
# 03
add(3, 'winding', 'A solid blue crate whose outside faces should be visible and lit.',
    cube(ifs_extra="ccw='false'"), cube(),
    'ccw is set to false although the faces are wound counter-clockwise seen from outside.',
    'The crate looks hollow or inside out: near faces culled, far inner faces visible.', 'legal, renders wrong')
# 04
n8 = ', '.join(' '.join(str(round(v * 0.577, 3)) for v in p) for p in
   [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)])
n6 = "0 0 1, 0 0 -1, 1 0 0, -1 0 0, 0 1 0, 0 -1 0"
add(4, 'normals', 'A smooth-shaded crate using one normal per vertex, as normalPerVertex says.',
    cube(inner=f"\n          <Normal vector='{n6}'/>"), cube(inner=f"\n          <Normal vector='{n8}'/>"),
    'Six per-face normals are supplied while normalPerVertex is true and there are eight vertices.',
    'Wrong or flat-looking shading on some corners, or normals ignored.', 'error: with normalPerVertex TRUE the Normal vector count must match the Coordinate count (or normalIndex)')
# 05
c8 = lambda s: ', '.join(' '.join(str(int(v * s)) if s > 1 else str(v) for v in c) for c in
   [(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),(0.5,0.5,0.5)])
add(5, 'colour', 'A crate with a different colour at each of its eight corners, blended smoothly.',
    cube(inner=f"\n          <Color color='{c8(255)}'/>", mat="<Material/>").replace("<Material/>", "<Material/>"),
    cube(inner=f"\n          <Color color='{c8(1)}'/>", mat="<Material/>"),
    'Colour components are written on a 0 to 255 scale instead of 0 to 1.',
    'Nearly every corner saturates to white, no visible colour blending.', 'error: Color components must lie in [0,1]')
# 06
proto = lambda fv: f"""    <ProtoDeclare name='Tower'>
      <ProtoInterface>
        <field accessType='initializeOnly' type='SFColor' name='towerColor' value='0.5 0.5 0.5'/>
        <field accessType='initializeOnly' type='SFFloat' name='towerHeight' value='1'/>
      </ProtoInterface>
      <ProtoBody>
        <Shape>
          <Appearance><Material>
            <IS><connect nodeField='diffuseColor' protoField='towerColor'/></IS>
          </Material></Appearance>
          <Cylinder radius='0.7'>
            <IS><connect nodeField='height' protoField='towerHeight'/></IS>
          </Cylinder>
        </Shape>
      </ProtoBody>
    </ProtoDeclare>
    <ProtoInstance name='Tower' DEF='RedTower'>
      <fieldValue name='{fv}' value='0.9 0.1 0.1'/>
      <fieldValue name='towerHeight' value='3'/>
    </ProtoInstance>
"""
add(6, 'proto', 'A tall red tower made by instancing a Tower prototype with a colour and a height.',
    proto('towerColour'), proto('towerColor'),
    'The ProtoInstance sets a field called towerColour but the prototype declares towerColor.',
    'The tower is the default grey, not red.', 'error: ProtoInstance fieldValue name must match a field declared in the ProtoInterface')
# 07
tex = "<PixelTexture image='2 2 3 0xFF0000 0x00FF00 0x0000FF 0xFFFF00'/>"
quad = lambda tc: f"""    <Shape>
      <Appearance><Material diffuseColor='1 1 1'/>{tex}</Appearance>
      <IndexedFaceSet coordIndex='0 1 2 3 -1'>
        <Coordinate point='-2 -2 0, 2 -2 0, 2 2 0, -2 2 0'/>
        <TextureCoordinate point='{tc}'/>
      </IndexedFaceSet>
    </Shape>
"""
add(7, 'texture-coordinates', 'A square panel showing the four-colour two by two texture exactly once, one colour per quadrant.',
    quad('0 0, 1 0, 1 1'), quad('0 0, 1 0, 1 1, 0 1'),
    'The TextureCoordinate holds three points for a four-vertex face.',
    'Texture smeared, a missing corner coordinate, or no texture.', 'error: TextureCoordinate count must cover every referenced vertex index')
# 08
ext = lambda cs: f"""    <Transform rotation='1 0 0 -0.4'>
      <Shape DEF='SquarePost'>
        <Appearance><Material diffuseColor='0.8 0.6 0.2'/></Appearance>
        <Extrusion crossSection='{cs}' spine='0 -1.5 0, 0 1.5 0' creaseAngle='0.5'/>
      </Shape>
    </Transform>
"""
add(8, 'extrusion', 'A square-section post extruded along a short straight spine.',
    ext('1 1, -1 -1, -1 1, 1 -1, 1 1'), ext('1 1, 1 -1, -1 -1, -1 1, 1 1'),
    'The cross-section points are ordered so the outline crosses itself (a bow-tie) instead of tracing the square.',
    'A twisted two-triangle bow-tie profile rather than a square post.', 'legal, renders wrong')
# 09
eg = lambda h: f"""    <Transform translation='-1.5 -0.5 -1' rotation='1 0 0 0.3'>
      <Shape DEF='Terrain'>
        <Appearance><Material diffuseColor='0.3 0.7 0.3'/></Appearance>
        <ElevationGrid xDimension='4' zDimension='3' xSpacing='1' zSpacing='1' height='{h}' solid='false'/>
      </Shape>
    </Transform>
"""
add(9, 'elevationgrid', 'A small four by three grid of terrain with a central ridge.',
    eg('0 0 0 0 0 1 1 0 0 0 0'), eg('0 0 0 0 0 1 1 0 0 0 0 1'),
    'height lists 11 values but xDimension times zDimension is 12.',
    'The terrain is missing or truncated.', 'error: ElevationGrid height must contain xDimension*zDimension values')
# 10
cps = ' '.join(f"{x} {((x+z)%2)} {z}," for x in (-1.5,-0.5,0.5,1.5) for z in (-1.5,-0.5,0.5,1.5)).rstrip(',')
nurbs = lambda uk: f"""    <Shape DEF='Canopy'>
      <Appearance><Material diffuseColor='0.9 0.8 0.3'/></Appearance>
      <NurbsPatchSurface uDimension='4' vDimension='4' uOrder='3' vOrder='3' uKnot='{uk}' vKnot='0 0 0 1 2 2 2' solid='false'>
        <CoordinateDouble point='{cps}' containerField='controlPoint'/>
      </NurbsPatchSurface>
    </Shape>
"""
add(10, 'nurbs', 'A rippled four by four NURBS canopy with quadratic basis in both directions.',
    nurbs('0 0 0 1 2 2'), nurbs('0 0 0 1 2 2 2'),
    'The uKnot vector has six values but uDimension plus uOrder needs seven.',
    'The surface does not appear or is badly distorted.', 'error: knot vector length must equal dimension + order',
    comps=[('NURBS', 1)])
# 11
nc = """    <Shape>
      <Appearance><Material emissiveColor='1 0.5 0'/></Appearance>
      <NurbsCurve order='3' knot='0 0 0 1 2 3 3 3'>
        <CoordinateDouble point='-3 0 0, -2 2 0, 0 -2 0, 2 2 0, 3 0 0'/>
      </NurbsCurve>
    </Shape>
"""
add(11, 'profile-component', 'An orange NURBS curve arching across the view.',
    nc, nc, 'The scene uses a NURBS node but neither the profile nor a component statement provides the NURBS component.',
    'Curve is missing or a console error says the node is unknown.', 'error: nodes must belong to the declared profile or components')
# 12
ud = lambda u: f"""    <Transform translation='-2 0 0'>
      <Shape DEF='Wheel'><Appearance><Material diffuseColor='0.2 0.2 0.2'/></Appearance><Cylinder radius='1' height='0.4'/></Shape>
    </Transform>
    <Transform translation='2 0 0'>
      <Shape USE='{u}'/>
    </Transform>
"""
add(12, 'def-use', 'Two identical wheels side by side: one defined, the second a reuse of the first.',
    ud('wheel'), ud('Wheel'),
    'USE refers to wheel but the node was defined as Wheel; names are case sensitive.',
    'Only one wheel appears and a console error reports the missing name.', 'error: USE must name a previously DEFed node (names are case-sensitive)')
# 13
dd = lambda d: f"""    <Transform translation='-2.5 0 0'>
      <Shape DEF='RedPost'><Appearance><Material diffuseColor='0.9 0.1 0.1'/></Appearance><Box size='0.5 3 0.5'/></Shape>
    </Transform>
    <Transform translation='0 0 0'>
      <Shape DEF='{d}'><Appearance><Material diffuseColor='0.1 0.1 0.9'/></Appearance><Sphere radius='0.8'/></Shape>
    </Transform>
    <Transform translation='2.5 0 0'>
      <Shape USE='RedPost'/>
    </Transform>
"""
add(13, 'def-use', 'A red post on the left, a blue ball in the middle, and a second red post on the right which is a reuse of the first.',
    dd('RedPost'), dd('BlueBall'),
    'The blue ball reuses the DEF name RedPost, so the later USE resolves to the ball.',
    'The right-hand object is a blue ball instead of a red post.', 'error: DEF names must be unique within a scope (a name may not be redefined with a different node)')
# 14
add(14, 'containment', 'A green cube given its colour through a Material.',
    "    <Shape>\n      <Material diffuseColor='0.1 0.8 0.2'/>\n      <Box/>\n    </Shape>\n",
    "    <Shape>\n      <Appearance><Material diffuseColor='0.1 0.8 0.2'/></Appearance>\n      <Box/>\n    </Shape>\n",
    'Material is placed directly in Shape instead of inside Appearance.',
    'The cube is rendered white or default, or the parser rejects the node.', 'error: Shape children are only appearance and geometry; Material belongs in Appearance')
# 15
door = lambda r: f"""    <Transform DEF='DoorHinge' translation='-1 0 0' rotation='0 1 0 {r}'>
      <Transform translation='1 0 0'>
        <Shape DEF='Door'><Appearance><Material diffuseColor='0.6 0.3 0.1'/></Appearance><Box size='2 3 0.2'/></Shape>
      </Transform>
    </Transform>
    <Shape><Appearance><Material diffuseColor='0.5 0.5 0.5'/></Appearance><Box size='0.2 3 0.2'/></Shape>
"""
add(15, 'angle-units', 'A door hinged on its left edge and swung open by a quarter turn (ninety degrees).',
    door('90'), door('1.5708'),
    'The rotation angle is written as 90, which X3D reads as ninety radians.',
    'The door is at an arbitrary angle (about 1.9 rad), not a right angle.', 'legal, renders wrong')
# 16
bx = "<Transform><Shape><Appearance><Material diffuseColor='0.6 0.6 0.9'/></Appearance><Box size='4 4 4'/></Shape></Transform>\n"
def vpfov(f):
    return f"    <Viewpoint position='0 0 12' fieldOfView='{f}' description='Wide'/>\n    " + bx
F[16] = dict(cat='angle-units', desc='A wide-angle (sixty degree) view of a four metre box seen from twelve metres.',
    fb=vpfov('60'), tb=vpfov('1.0472'), fault='fieldOfView is given as 60 (degrees) but is in radians and must be in (0, pi).',
    seen='Extremely distorted or wrongly clamped view of the box.', spec='error: Viewpoint fieldOfView must be in the range (0, pi)', profile='Interchange', comps='')
# 17
lit = lambda nav: f"""    <NavigationInfo {nav}/>
    <Transform><Shape><Appearance><Material diffuseColor='0.9 0.7 0.2'/></Appearance><Sphere radius='1.5'/></Shape></Transform>
"""
add(17, 'navigation-lighting', 'A yellow sphere lit by the default headlight.',
    lit("headlight='false'"), lit("headlight='true'"),
    'The headlight is switched off and the scene has no other light, so the lit sphere is unlit.',
    'A black sphere on the background.', 'legal, renders wrong')
# 18
sw = lambda w: f"""    <Switch whichChoice='{w}'>
      <Shape><Appearance><Material diffuseColor='1 0 0'/></Appearance><Box/></Shape>
      <Shape><Appearance><Material diffuseColor='0 1 0'/></Appearance><Sphere/></Shape>
      <Shape><Appearance><Material diffuseColor='0 0 1'/></Appearance><Cone/></Shape>
    </Switch>
"""
add(18, 'lod-switch', 'A switch of three shapes (box, sphere, cone) set to show the third one, the blue cone.',
    sw('3'), sw('2'),
    'whichChoice is 3, counted from one, but choices are indexed from zero so index 3 selects nothing.',
    'Nothing is drawn.', 'legal, renders wrong')
# 19
mat = lambda s: f"<Material diffuseColor='0.8 0.1 0.1' specularColor='1 1 1' shininess='{s}'/>"
add(19, 'material-range', 'A red glossy sphere with a moderate highlight.',
    sph("radius='1.5'", mat('50')), sph("radius='1.5'", mat('0.5')),
    'shininess is 50 where the legal range is 0 to 1.', 'Rock-hard tiny highlight (value clamps to 1).', 'error: Material shininess must lie in [0,1]')
# 20
dl = lambda d: f"""    <NavigationInfo headlight='false'/>
    <DirectionalLight DEF='Sun' direction='{d}' intensity='1'/>
    <Transform><Shape><Appearance><Material diffuseColor='0.8 0.8 0.8'/></Appearance><Sphere radius='1.5'/></Shape></Transform>
"""
add(20, 'lights', 'A grey sphere lit from straight above by a sun, with the headlight off.',
    dl('0 0 0'), dl('0 -1 0'),
    'The DirectionalLight direction is the zero vector.', 'Sphere is black or lit incorrectly.', 'error: DirectionalLight direction must be a non-zero vector')

for n, d in F.items():
    write('fault-%02d.x3d' % n, d['desc'], d['fb'], d['profile'], d['comps'])
    tb = d['tb']
    tcomps = d['comps']
    if n == 11: tcomps = [('NURBS', 1)]
    write('twin-%02d.x3d' % n, d['desc'], tb, d['profile'], tcomps)

# decoys
DEC = {}
def dec(n, desc, body, why, intent=None, **kw):
    DEC[n] = dict(desc=desc, why=why)
    write('decoy-%02d.x3d' % n, desc, VP + body, **kw)
dec(1, 'Two crates facing each other: the left one is a mirror image of the right, made with a negative scale.',
 """    <Transform translation='3 0 0'><Shape DEF='Wedge'><Appearance><Material diffuseColor='0.8 0.4 0.1'/></Appearance>
      <IndexedFaceSet coordIndex='0 1 2 -1 0 2 3 -1 0 3 1 -1 1 3 2 -1'><Coordinate point='0 0 0, 2 0 0, 0 2 0, 0 0 2'/></IndexedFaceSet></Shape></Transform>
    <Transform translation='-3 0 0' scale='-1 1 1'><Shape USE='Wedge'/></Transform>
""", 'Negative scale looks like a bad value, but mirroring is legal.')
dec(2, 'A coloured cube using separate colour indices and a Color list shorter than the vertex list.',
 "    <Transform rotation='1 1 0 0.6'><Shape><Appearance><Material/></Appearance><IndexedFaceSet coordIndex='" + CUBE_IDX + "' colorIndex='0 0 1 1 -1 1 1 0 0 -1 0 1 0 1 -1 1 0 1 0 -1 0 0 0 0 -1 1 1 1 1 -1' colorPerVertex='true'><Coordinate point='" + CUBE_PTS + "'/><Color color='1 0 0, 0 0 1'/></IndexedFaceSet></Shape></Transform>\n",
 'Two colours for eight vertices looks like a count mismatch, but colorIndex legally maps vertices to colours.')
dec(3, 'Spinning-looking orientations: rotation angles outside the 0 to two-pi range, including a negative one.',
 """    <Transform translation='-3 0 0' rotation='0 1 0 7.0'><Shape><Appearance><Material diffuseColor='0.9 0.2 0.2'/></Appearance><Cone/></Shape></Transform>
    <Transform rotation='1 0 0 -1.5708'><Shape><Appearance><Material diffuseColor='0.2 0.9 0.2'/></Appearance><Cone/></Shape></Transform>
    <Transform translation='3 0 0' rotation='0 0 1 12.566'><Shape><Appearance><Material diffuseColor='0.2 0.2 0.9'/></Appearance><Cone/></Shape></Transform>
""", 'Angles 7.0, negative and 4pi look out of range but SFRotation angles are unbounded.')
dec(4, 'A DEFed shape inside an unselected Switch child is reused by USE elsewhere; an empty LOD range list is also used.',
 """    <Switch whichChoice='-1'><Shape DEF='Hidden'><Appearance><Material diffuseColor='0.9 0.5 0.1'/></Appearance><Box size='1 1 1'/></Shape></Switch>
    <Transform translation='-2 0 0'><Shape USE='Hidden'/></Transform>
    <Transform translation='2 0 0'>
      <LOD range=''>
        <Shape><Appearance><Material diffuseColor='0.1 0.5 0.9'/></Appearance><Sphere/></Shape>
        <Shape><Appearance><Material diffuseColor='0.1 0.9 0.5'/></Appearance><Cone/></Shape>
      </LOD>
    </Transform>
""", 'USE of a node inside a Switch that shows nothing, and an empty LOD range, look broken but are legal.')
dec(5, 'A prototype whose body defines a node and reuses it internally, instanced once with defaults only and once with an override.',
 """    <ProtoDeclare name='Ball'>
      <ProtoInterface><field accessType='initializeOnly' type='SFColor' name='tint' value='0.9 0.3 0.3'/></ProtoInterface>
      <ProtoBody>
        <Group>
          <Shape DEF='Orb'><Appearance><Material><IS><connect nodeField='diffuseColor' protoField='tint'/></IS></Material></Appearance><Sphere radius='0.8'/></Shape>
          <Transform translation='0 1.4 0' scale='0.5 0.5 0.5'><Shape USE='Orb'/></Transform>
        </Group>
      </ProtoBody>
    </ProtoDeclare>
    <Transform translation='-2 -1 0'><ProtoInstance name='Ball'/></Transform>
    <Transform translation='2 -1 0'><ProtoInstance name='Ball'><fieldValue name='tint' value='0.3 0.3 0.9'/></ProtoInstance></Transform>
""", 'Instance with no fieldValue and a USE inside a proto body look unfinished, but defaults and body-internal reuse are legal.')

M = {}
for n, d in F.items():
    M['fault-%02d.x3d' % n] = dict(category=d['cat'], fault=d['fault'], viewer_sees=d['seen'], spec=d['spec'], xsd_valid=None, witness=None, witness_note=None, twin='twin-%02d.x3d' % n)
    M['twin-%02d.x3d' % n] = dict(category=d['cat'], intent=d['desc'], xsd_valid=None, witness=None, witness_note=None)
for n, d in DEC.items():
    M['decoy-%02d.x3d' % n] = dict(category='decoy', intent=d['desc'], why_suspicious=d['why'], xsd_valid=None, witness=None, witness_note=None)
json.dump(M, open(os.path.join(D, 'MANIFEST.json'), 'w'), indent=1)
