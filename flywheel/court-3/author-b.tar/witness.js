const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');           // court3 (kit + author-b), only these used
const PAGE = `<!doctype html><html><head><meta charset=utf-8><script src="/kit/x_ite/x_ite.min.js"></script></head>
<body style="margin:0"><x3d-canvas id=c src="/author-b/FILE" style="width:400px;height:300px"></x3d-canvas></body></html>`;
const srv = http.createServer((q, r) => {
  const u = new URL(q.url, 'http://x');
  if (u.pathname === '/page.html') { r.setHeader('content-type', 'text/html'); return r.end(PAGE.replace('FILE', u.searchParams.get('f'))); }
  const p = path.join(ROOT, u.pathname);
  if (!p.startsWith(ROOT) || u.pathname.startsWith('/author-a')) { r.statusCode = 403; return r.end(); }
  fs.readFile(p, (e, d) => { if (e) { r.statusCode = 404; return r.end(); }
    r.setHeader('content-type', p.endsWith('.js') ? 'text/javascript' : p.endsWith('.css') ? 'text/css' : 'application/xml'); r.end(d); });
}).listen(0);
const files = fs.readdirSync(__dirname).filter(f => /^(fault|twin|decoy)-\d+\.x3d$/.test(f)).sort();
const SH = '/tmp/b-shots'; fs.mkdirSync(SH, { recursive: true });
(async () => {
  const port = srv.address().port;
  const br = await chromium.launch();
  const res = {};
  for (const f of files) {
    const pg = await br.newPage({ viewport: { width: 400, height: 300 } });
    const logs = [];
    pg.on('console', m => { if (['error', 'warning'].includes(m.type())) logs.push(m.type() + ': ' + m.text().slice(0, 300)); });
    pg.on('response', rs => { if (rs.status() >= 400) logs.push('HTTP ' + rs.status() + ' ' + rs.url()); }); pg.on('pageerror', e => logs.push('pageerror: ' + String(e).slice(0, 300)));
    await pg.goto(`http://127.0.0.1:${port}/page.html?f=${f}`);
    await pg.waitForTimeout(3500);
    let info = {};
    try {
      info = await pg.evaluate(() => {
        const b = document.getElementById('c').browser; const s = b.currentScene;
        return { rootNodes: s.rootNodes.length, profile: s.profile && s.profile.name, loadState: String(b.getBrowserProperty ? '' : '') };
      });
    } catch (e) { info = { sai_error: String(e).slice(0, 200) }; }
    await pg.screenshot({ path: `${SH}/${f}.png` });
    res[f] = { info, console: logs };
    await pg.close();
  }
  // pixel compare in a blank page
  const cp = await br.newPage();
  const cmp = async (a, b) => {
    const A = fs.readFileSync(`${SH}/${a}.png`).toString('base64'), B = fs.readFileSync(`${SH}/${b}.png`).toString('base64');
    return cp.evaluate(async ([A, B]) => {
      const ld = async s => { const i = await createImageBitmap(await (await fetch('data:image/png;base64,' + s)).blob()); const c = new OffscreenCanvas(i.width, i.height); const x = c.getContext('2d'); x.drawImage(i, 0, 0); return x.getImageData(0, 0, i.width, i.height).data; };
      const a = await ld(A), b = await ld(B); let d = 0, n = a.length / 4, bg = 0;
      for (let i = 0; i < a.length; i += 4) if (Math.abs(a[i] - b[i]) + Math.abs(a[i + 1] - b[i + 1]) + Math.abs(a[i + 2] - b[i + 2]) > 30) d++;
      return d / n;
    }, [A, B]);
  };
  // fraction of non-background pixels (background = top-left pixel colour)
  const fill = async (a) => {
    const A = fs.readFileSync(`${SH}/${a}.png`).toString('base64');
    return cp.evaluate(async (A) => { const i = await createImageBitmap(await (await fetch('data:image/png;base64,' + A)).blob()); const c = new OffscreenCanvas(i.width, i.height); const x = c.getContext('2d'); x.drawImage(i, 0, 0); const d = x.getImageData(0, 0, i.width, i.height).data; let k = 0; for (let j = 0; j < d.length; j += 4) if (Math.abs(d[j] - d[0]) + Math.abs(d[j + 1] - d[1]) + Math.abs(d[j + 2] - d[2]) > 30) k++; return k / (d.length / 4); }, A);
  };
  for (const f of files) { res[f].nonbg_fraction = await fill(f); }
  for (let n = 1; n <= 20; n++) { const nn = String(n).padStart(2, '0'); res[`fault-${nn}.x3d`].diff_vs_twin = await cmp(`fault-${nn}.x3d`, `twin-${nn}.x3d`); }
  res._env = { chromium: br.version(), gl: await (async () => { const p = await br.newPage(); await p.goto('about:blank'); const r = await p.evaluate(() => { const g = document.createElement('canvas').getContext('webgl2') || document.createElement('canvas').getContext('webgl'); if (!g) return 'none'; const e = g.getExtension('WEBGL_debug_renderer_info'); return e ? g.getParameter(e.UNMASKED_RENDERER_WEBGL) : g.getParameter(g.RENDERER); }); return r; })() };
  fs.writeFileSync(path.join(__dirname, 'witness.json'), JSON.stringify(res, null, 1));
  await br.close(); srv.close();
})();
