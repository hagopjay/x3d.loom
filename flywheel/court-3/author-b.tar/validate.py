import glob, json
from lxml import etree
sch = etree.XMLSchema(etree.parse('../kit/xsd/x3d-4.0.xsd'))
out = {}
for f in sorted(glob.glob('*.x3d')):
    try:
        d = etree.parse(f)
    except Exception as e:
        out[f] = {'wellformed': False, 'err': str(e)}; continue
    ok = sch.validate(d)
    out[f] = {'wellformed': True, 'xsd_valid': ok, 'err': [str(e) for e in sch.error_log][:2]}
json.dump(out, open('xsd.json', 'w'), indent=1)
for f, r in out.items():
    if not r.get('xsd_valid'): print(f, r)
